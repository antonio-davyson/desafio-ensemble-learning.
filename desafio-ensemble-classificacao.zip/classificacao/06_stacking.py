# %% [markdown]
# # 06 — Stacking
# Meta-modelo (regressão logística) aprende a combinar as previsões, obtidas por validação cruzada, de vários modelos-base.
# %%
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier, ExtraTreesClassifier, StackingClassifier
from utils import carregar, treinar_e_avaliar, salvar, SEED

X_tr, y_tr, X_te, y_te = carregar(); print("Treino:", X_tr.shape, "| Teste completo:", X_te.shape)
base = [("lr", LogisticRegression(max_iter=1000)),
        ("rf", RandomForestClassifier(n_estimators=100, random_state=SEED)),
        ("et", ExtraTreesClassifier(n_estimators=100, random_state=SEED)),
        ("hgb", HistGradientBoostingClassifier(max_iter=200, random_state=SEED))]
modelos = {f"{n} (base)": m for n, m in base}
modelos["Stacking (meta=LR)"] = StackingClassifier(base, final_estimator=LogisticRegression(max_iter=1000), cv=5, stack_method="predict_proba")
modelos["Stacking (meta=HGB)"] = StackingClassifier(base, final_estimator=HistGradientBoostingClassifier(max_iter=100, random_state=SEED), cv=5, stack_method="predict_proba")
res = [treinar_e_avaliar(n, m, X_tr, y_tr, X_te, y_te) for n, m in modelos.items()]
salvar(res, "stacking")
