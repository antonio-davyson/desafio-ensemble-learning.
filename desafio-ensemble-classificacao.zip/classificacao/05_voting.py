# %% [markdown]
# # 05 — Voting (hard e soft)
# %%
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier, VotingClassifier
from utils import carregar, treinar_e_avaliar, salvar, SEED

X_tr, y_tr, X_te, y_te = carregar(); print("Treino:", X_tr.shape, "| Teste completo:", X_te.shape)
base = [("lr", LogisticRegression(max_iter=1000)),
        ("rf", RandomForestClassifier(n_estimators=200, random_state=SEED)),
        ("hgb", HistGradientBoostingClassifier(max_iter=300, random_state=SEED))]
modelos = {f"{n} (base)": m for n, m in base}
modelos["Voting hard"] = VotingClassifier(base, voting="hard")
modelos["Voting soft"] = VotingClassifier(base, voting="soft")
modelos["Voting soft (pesos 1:2:2)"] = VotingClassifier(base, voting="soft", weights=[1, 2, 2])
# o VotingClassifier hard não tem predict_proba: avaliamos só com as previsões (AUC usa a probabilidade do soft)
import numpy as np
from utils import avaliar
import time
res = []
for n, m in modelos.items():
    if n == "Voting hard":
        t = time.time(); m.fit(X_tr, y_tr); t = time.time() - t
        from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
        p = m.predict(X_te); r = {"modelo": n, "acurácia": accuracy_score(y_te, p), "precisão": precision_score(y_te, p), "recall": recall_score(y_te, p),
                                  "F1": f1_score(y_te, p), "AUC": np.nan, "tempo_treino_s": t}
        print(f"{n:28s} acc={r['acurácia']:.4f} F1={r['F1']:.4f} AUC=  n/a ({t:.0f}s)"); res.append(r)
    else:
        res.append(treinar_e_avaliar(n, m, X_tr, y_tr, X_te, y_te))
salvar(res, "voting")
