# %% [markdown]
# # 01 — EDA: Airline Passenger Satisfaction (classificação)
# %%
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

train = pd.read_csv("data/train.csv"); test = pd.read_csv("data/test.csv")

# %% 1. Tamanho, tipos e nulos
print("train:", train.shape, "| test:", test.shape)
print(train.dtypes.value_counts().to_dict())
print(train.nunique().sort_values().head(12))
nulos = train.isna().sum(); print(nulos[nulos > 0])
print("Duplicados (sem id e índice):", train.drop(columns=["Unnamed: 0", "id"]).duplicated().sum(), "| ids repetidos:", train["id"].duplicated().sum())

# %% 2. Alvo
print(train["satisfaction"].value_counts(normalize=True).round(3))
print(test["satisfaction"].value_counts(normalize=True).round(3))

# %% 3. Categóricas x alvo
alvo = (train["satisfaction"] == "satisfied").astype(int)
for c in ["Gender", "Customer Type", "Type of Travel", "Class"]:
    print(alvo.groupby(train[c]).agg(["mean", "count"]).round(3).rename(columns={"mean": "% satisfeitos"}))

# %% 4. Numéricas: estatísticas, outliers (1,5×IQR) e correlação com o alvo
num_cont = ["Age", "Flight Distance", "Departure Delay in Minutes", "Arrival Delay in Minutes"]
print(train[num_cont].describe().round(1))
for c in num_cont:
    s = train[c].dropna(); q1, q3 = s.quantile([.25, .75]); lim = q3 + 1.5 * (q3 - q1)
    print(f"{c}: {(s > lim).sum()} valores acima de {lim:.0f} ({(s > lim).mean()*100:.1f}%) | máx={s.max():.0f}")
print("Correlação Departure x Arrival delay:", round(train["Departure Delay in Minutes"].corr(train["Arrival Delay in Minutes"]), 3))
notas = [c for c in train.columns if pd.api.types.is_numeric_dtype(train[c]) and c not in num_cont + ["Unnamed: 0", "id"] and train[c].nunique() <= 6]
print("Colunas de nota (0–5):", len(notas))
print("Zeros (\"não se aplica\") por nota (%):", (train[notas] == 0).mean().mul(100).round(1).sort_values(ascending=False).head(6).to_dict())
corr = train[notas + num_cont].corrwith(alvo).sort_values(ascending=False); print(corr.round(3))

# %% 5. Gráficos
fig, ax = plt.subplots(2, 3, figsize=(16, 8))
alvo.value_counts().rename({0: "neutro/insatisfeito", 1: "satisfeito"}).plot.bar(ax=ax[0, 0], color="#2563eb", rot=0); ax[0, 0].set_title("Alvo")
for a, c in zip(ax.ravel()[1:4], ["Class", "Type of Travel", "Customer Type"]):
    alvo.groupby(train[c]).mean().plot.bar(ax=a, color="#2563eb", rot=0); a.set_title(f"% satisfeitos por {c}"); a.set_ylim(0, 1)
corr.sort_values().plot.barh(ax=ax[1, 0], color="#2563eb"); ax[1, 0].set_title("Correlação com satisfação")
train["Departure Delay in Minutes"].clip(upper=300).hist(bins=60, ax=ax[1, 1], color="#2563eb"); ax[1, 1].set_yscale("log"); ax[1, 1].set_title("Atraso na partida (cortado em 300 min, y em log)")
plt.tight_layout(); plt.savefig("eda_classificacao.png", dpi=110); plt.close()
