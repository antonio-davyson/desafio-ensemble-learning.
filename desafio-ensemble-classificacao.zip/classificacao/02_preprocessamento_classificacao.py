# %% [markdown]
# # 02 — Pré-processamento: Airline Passenger Satisfaction
# Gera `data/airline_train_clean.csv.gz` e `data/airline_test_clean.csv.gz` (compactados para caber no limite de upload do GitHub). Todas as estatísticas são aprendidas no treino e só aplicadas no teste (sem vazamento).
# %%
import pandas as pd, numpy as np
from sklearn.preprocessing import StandardScaler

train = pd.read_csv("data/train.csv"); test = pd.read_csv("data/test.csv")

def limpar(df):
    df = df.drop(columns=["Unnamed: 0", "id"]).copy()                      # índice e identificador não têm valor preditivo
    # Nulos em 'Arrival Delay in Minutes' (0,3%): o atraso na chegada é quase igual ao da partida (correlação 0,965), então usamos o atraso da partida
    df["Arrival Delay in Minutes"] = df["Arrival Delay in Minutes"].fillna(df["Departure Delay in Minutes"])
    # Categóricas binárias -> 0/1; 'Class' é ordinal (Eco < Eco Plus < Business)
    df["Gender"] = (df["Gender"] == "Male").astype(int)
    df["Customer Type"] = (df["Customer Type"] == "Loyal Customer").astype(int)
    df["Type of Travel"] = (df["Type of Travel"] == "Business travel").astype(int)
    df["Class"] = df["Class"].map({"Eco": 0, "Eco Plus": 1, "Business": 2})
    df["satisfaction"] = (df["satisfaction"] == "satisfied").astype(int)    # alvo: 1 = satisfeito
    return df

tr, te = limpar(train), limpar(test)
assert tr.isna().sum().sum() == 0 and te.isna().sum().sum() == 0

# %% Escalonamento (padronização) de todas as variáveis de entrada, ajustado só no treino
X_cols = [c for c in tr.columns if c != "satisfaction"]
esc = StandardScaler().fit(tr[X_cols])
tr_s = pd.DataFrame(esc.transform(tr[X_cols]), columns=X_cols).assign(satisfaction=tr["satisfaction"].values)
te_s = pd.DataFrame(esc.transform(te[X_cols]), columns=X_cols).assign(satisfaction=te["satisfaction"].values)

tr_s.to_csv("data/airline_train_clean.csv.gz", index=False); te_s.to_csv("data/airline_test_clean.csv.gz", index=False)
print("Treino:", tr_s.shape, "| Teste:", te_s.shape, "| nulos:", int(tr_s.isna().sum().sum() + te_s.isna().sum().sum()))
print("Proporção de satisfeitos: treino", round(tr_s["satisfaction"].mean(), 3), "| teste", round(te_s["satisfaction"].mean(), 3))
print("Features:", X_cols)
