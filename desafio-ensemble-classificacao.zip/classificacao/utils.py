"""Funções comuns aos scripts de treino (carga dos dados limpos, amostragem estratificada e métricas)."""
import json, time, numpy as np, pandas as pd
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix

N_AMOSTRA = None       # None = treino completo (103.904 linhas). Se ficar lento, use por exemplo 30000 (amostra estratificada)
SEED = 42

def carregar(n_amostra=N_AMOSTRA):
    tr = pd.read_csv("data/airline_train_clean.csv.gz"); te = pd.read_csv("data/airline_test_clean.csv.gz")
    if n_amostra and n_amostra < len(tr):
        from sklearn.model_selection import train_test_split
        tr, _ = train_test_split(tr, train_size=n_amostra, stratify=tr["satisfaction"], random_state=SEED)   # amostra estratificada
    return tr.drop(columns="satisfaction"), tr["satisfaction"], te.drop(columns="satisfaction"), te["satisfaction"]

def avaliar(nome, modelo, X_te, y_te, t_treino):
    pred = modelo.predict(X_te); proba = modelo.predict_proba(X_te)[:, 1]
    tn, fp, fn, tp = confusion_matrix(y_te, pred).ravel()
    r = {"modelo": nome, "acurácia": accuracy_score(y_te, pred), "precisão": precision_score(y_te, pred), "recall": recall_score(y_te, pred),
         "F1": f1_score(y_te, pred), "AUC": roc_auc_score(y_te, proba), "tempo_treino_s": t_treino}
    print(f"{nome:28s} acc={r['acurácia']:.4f} F1={r['F1']:.4f} AUC={r['AUC']:.4f} ({t_treino:.0f}s)")
    return r

def treinar_e_avaliar(nome, modelo, X_tr, y_tr, X_te, y_te):
    t = time.time(); modelo.fit(X_tr, y_tr); return avaliar(nome, modelo, X_te, y_te, time.time() - t)

def salvar(resultados, arquivo):
    pd.DataFrame(resultados).round(4).to_csv(f"resultados/{arquivo}.csv", index=False)
