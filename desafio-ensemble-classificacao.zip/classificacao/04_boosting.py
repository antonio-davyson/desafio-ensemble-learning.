# %% [markdown]
# # 04 — Boosting (AdaBoost, Gradient Boosting, HistGradientBoosting)
# %%
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import AdaBoostClassifier, GradientBoostingClassifier, HistGradientBoostingClassifier
from utils import carregar, treinar_e_avaliar, salvar, SEED

X_tr, y_tr, X_te, y_te = carregar(); print("Treino:", X_tr.shape, "| Teste completo:", X_te.shape)
modelos = {
    "Árvore única (base)": DecisionTreeClassifier(random_state=SEED),
    "AdaBoost (200, depth=2)": AdaBoostClassifier(DecisionTreeClassifier(max_depth=2), n_estimators=200, learning_rate=0.5, random_state=SEED),
    "Gradient Boosting (200)": GradientBoostingClassifier(n_estimators=200, learning_rate=0.1, max_depth=3, random_state=SEED),
    "HistGradientBoosting": HistGradientBoostingClassifier(max_iter=300, learning_rate=0.1, random_state=SEED),
}
res = [treinar_e_avaliar(n, m, X_tr, y_tr, X_te, y_te) for n, m in modelos.items()]
salvar(res, "boosting")
