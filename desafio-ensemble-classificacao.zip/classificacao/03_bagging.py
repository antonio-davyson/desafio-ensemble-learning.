# %% [markdown]
# # 03 — Bagging (Bagging, Random Forest, Extra Trees) vs. árvore única
# %%
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import BaggingClassifier, RandomForestClassifier, ExtraTreesClassifier
from sklearn.linear_model import LogisticRegression
from utils import carregar, treinar_e_avaliar, salvar, SEED

X_tr, y_tr, X_te, y_te = carregar(); print("Treino:", X_tr.shape, "| Teste completo:", X_te.shape)
modelos = {
    "Regressão logística (base)": LogisticRegression(max_iter=1000),
    "Árvore única (base)": DecisionTreeClassifier(random_state=SEED),
    "Bagging (100 árvores)": BaggingClassifier(DecisionTreeClassifier(), n_estimators=100, random_state=SEED),
    "Random Forest (200)": RandomForestClassifier(n_estimators=200, random_state=SEED),
    "Extra Trees (200)": ExtraTreesClassifier(n_estimators=200, random_state=SEED),
}
res = [treinar_e_avaliar(n, m, X_tr, y_tr, X_te, y_te) for n, m in modelos.items()]
salvar(res, "bagging")

# Importância das variáveis (Random Forest)
import pandas as pd
imp = pd.Series(modelos["Random Forest (200)"].feature_importances_, index=X_tr.columns).sort_values(ascending=False)
print(imp.head(8).round(3)); imp.round(4).to_csv("resultados/importancia_random_forest.csv")
