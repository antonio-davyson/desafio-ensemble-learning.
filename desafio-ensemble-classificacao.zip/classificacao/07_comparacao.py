# %% [markdown]
# # 07 — Comparação final dos ensembles (lê os resultados salvos pelos scripts 03 a 06)
# %%
import pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

partes = [pd.read_csv(f"resultados/{a}.csv").assign(tecnica=t) for a, t in
          [("bagging", "Bagging"), ("boosting", "Boosting"), ("voting", "Voting"), ("stacking", "Stacking")]]
df = pd.concat(partes)
df = df[~df["modelo"].str.contains("base") | df["modelo"].isin(["Regressão logística (base)", "Árvore única (base)"])]
df = df.drop_duplicates("modelo").sort_values("F1", ascending=False).reset_index(drop=True)
print(df[["modelo", "tecnica", "acurácia", "F1", "AUC", "tempo_treino_s"]].to_string())
df.to_csv("resultados/comparacao.csv", index=False)

cores = {"Bagging": "#2563eb", "Boosting": "#dc2626", "Voting": "#16a34a", "Stacking": "#9333ea"}
d = df.sort_values("F1")
plt.figure(figsize=(9, 6)); plt.barh(d["modelo"], d["F1"], color=[cores.get(t, "#9ca3af") for t in d["tecnica"]])
plt.xlim(0.8, 0.97); plt.xlabel("F1 no teste"); plt.title("Airline Satisfaction — ensembles vs. modelos base"); plt.tight_layout(); plt.savefig("comparacao.png", dpi=120)
